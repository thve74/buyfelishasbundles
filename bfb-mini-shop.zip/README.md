# BuyFelishasBundles — Mini Shop (GitHub Pages)
Upload all files in this ZIP to your new repo **buyfelishasbundles** (root). Then enable GitHub Pages (Settings → Pages → Deploy from a branch).